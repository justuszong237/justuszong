import { Request, Response } from 'express';

class IndexController {
    public getTransactions(req: Request, res: Response): void {
        // Logic to retrieve transactions
        res.send('Retrieve transactions');
    }

    public createTransaction(req: Request, res: Response): void {
        // Logic to create a new transaction
        res.send('Create a new transaction');
    }
}

export default IndexController;