import { Router } from 'express';
import IndexController from '../controllers/index';

const router = Router();
const indexController = new IndexController();

export function setRoutes(app) {
    app.use('/api/transactions', router);
    router.get('/', indexController.getTransactions.bind(indexController));
    router.post('/', indexController.createTransaction.bind(indexController));
}